import ChatPage from "./components/ChatPage";

export default function App() {
  return (
    <div className="min-vh-100 bg-light">
      <ChatPage />
    </div>
  );
}
