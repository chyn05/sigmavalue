import pandas as pd
from functools import lru_cache
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
DATA_FILE = BASE_DIR / "data" / "Sample_data.xlsx"

class DatasetNotFoundError(Exception):
    pass

@lru_cache(maxsize=1)
def load_dataset() -> pd.DataFrame:
    if not DATA_FILE.exists():
        raise DatasetNotFoundError(f"Dataset file not found at: {DATA_FILE}")
    df = pd.read_excel(DATA_FILE)
    df.columns = [c.strip().lower() for c in df.columns]
    return df

def filter_by_area(df: pd.DataFrame, areas: list[str]) -> pd.DataFrame:
    if "area" not in df.columns:
        return df
    areas_lower = [a.lower() for a in areas]
    return df[df["area"].str.lower().isin(areas_lower)]
