import re
from typing import Tuple, List

def extract_areas(query: str) -> List[str]:
    text = query.lower()
    parts = re.split(r"\band\b|,|/|vs|versus", text)
    blacklist_phrases = [
        "give me analysis of",
        "analysis of",
        "analyze",
        "compare",
        "show",
        "price growth for",
        "demand for",
        "in",
    ]
    cleaned = []
    for p in parts:
        s = p.strip()
        for phrase in blacklist_phrases:
            s = s.replace(phrase, "").strip()
        if s:
            cleaned.append(s.title())
    unique = list(dict.fromkeys(cleaned))
    return unique

def detect_metric(query: str) -> str:
    q = query.lower()
    has_price = "price" in q
    has_demand = "demand" in q
    if has_price and has_demand:
        return "both"
    if has_price:
        return "price"
    if has_demand:
        return "demand"
    return "both"

def detect_year_range(query: str) -> Tuple[int | None, int | None]:
    years = re.findall(r"(20[0-3][0-9])", query)
    if not years:
        return None, None
    years_int = sorted({int(y) for y in years})
    return years_int[0], years_int[-1]
